import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { ThumbsUp, MessageSquare, Search, PlusCircle } from 'lucide-react'
import { Textarea } from '@/components/ui/textarea'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { CommunityPost, User } from '@/types'
import { getUsers } from '@/services/api'
import { formatDistanceToNow } from 'date-fns'
import { ptBR } from 'date-fns/locale'
import { Skeleton } from '@/components/ui/skeleton'

const mockPosts: CommunityPost[] = [
  {
    id: '1',
    userId: 1,
    title: 'Qual a melhor forma de estudar para o ENEM?',
    content:
      'Estou começando a me preparar para o ENEM e queria saber quais métodos de estudo vocês mais recomendam. Alguma dica de cronograma ou material?',
    timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
    likes: [2, 3],
    comments: [],
  },
  {
    id: '2',
    userId: 2,
    title: 'Dica de vídeo sobre Revolução Francesa!',
    content:
      'Encontrei um vídeo incrível que explica a Revolução Francesa de um jeito super didático. Recomendo muito!',
    timestamp: new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString(),
    likes: [1, 3, 4],
    comments: [],
  },
]

export default function Community() {
  const [posts, setPosts] = useState<CommunityPost[]>(mockPosts)
  const [users, setUsers] = useState<User[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        const usersData = await getUsers()
        setUsers(usersData)
      } catch (error) {
        console.error('Failed to fetch users:', error)
      } finally {
        setLoading(false)
      }
    }
    fetchData()
  }, [])

  const getUserById = (id: number) => {
    return users.find((user) => user.id === id)
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex flex-col md:flex-row justify-between items-center mb-8 gap-4">
        <div>
          <h1 className="text-4xl font-bold">Comunidade Subjescts</h1>
          <p className="text-muted-foreground mt-2">
            Conecte-se, tire dúvidas e colabore com outros estudantes.
          </p>
        </div>
        <Dialog>
          <DialogTrigger asChild>
            <Button>
              <PlusCircle className="mr-2 h-4 w-4" /> Criar Nova Publicação
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Nova Publicação</DialogTitle>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <Input placeholder="Título da sua publicação" />
              <Textarea
                placeholder="Escreva sua dúvida ou dica aqui..."
                rows={5}
              />
              <Button>Publicar</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="relative mb-8">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
        <Input placeholder="Buscar por tópicos ou posts..." className="pl-10" />
      </div>

      <div className="space-y-6">
        {loading
          ? Array.from({ length: 2 }).map((_, i) => (
              <Card key={i}>
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <Skeleton className="h-12 w-12 rounded-full" />
                    <div className="space-y-2">
                      <Skeleton className="h-4 w-24" />
                      <Skeleton className="h-3 w-16" />
                    </div>
                  </div>
                  <Skeleton className="h-6 w-3/4 mt-4" />
                </CardHeader>
                <CardContent>
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-5/6 mt-2" />
                </CardContent>
                <CardFooter className="border-t pt-4">
                  <Skeleton className="h-8 w-24" />
                </CardFooter>
              </Card>
            ))
          : posts.map((post) => {
              const user = getUserById(post.userId)
              return (
                <Card key={post.id}>
                  <CardHeader>
                    <div className="flex items-center gap-3">
                      <Avatar>
                        <AvatarImage src={user?.avatarUrl} />
                        <AvatarFallback>{user?.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-semibold">{user?.name}</p>
                        <p className="text-xs text-muted-foreground">
                          {formatDistanceToNow(new Date(post.timestamp), {
                            addSuffix: true,
                            locale: ptBR,
                          })}
                        </p>
                      </div>
                    </div>
                    <CardTitle className="text-xl mt-4">{post.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">{post.content}</p>
                  </CardContent>
                  <CardFooter className="flex items-center gap-6 border-t pt-4">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="flex items-center gap-2"
                    >
                      <ThumbsUp className="h-4 w-4" /> {post.likes.length}
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="flex items-center gap-2"
                    >
                      <MessageSquare className="h-4 w-4" />{' '}
                      {post.comments.length} Comentários
                    </Button>
                  </CardFooter>
                </Card>
              )
            })}
      </div>
    </div>
  )
}
