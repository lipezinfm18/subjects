import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import * as z from 'zod'
import { Button } from '@/components/ui/button'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form'
import { Progress } from '@/components/ui/progress'
import { UploadCloud } from 'lucide-react'
import { useToast } from '@/components/ui/use-toast'
import { useAuth } from '@/contexts/AuthContext'
import { createVideo } from '@/services/api'

const MAX_FILE_SIZE = 500 * 1024 * 1024 // 500MB
const ACCEPTED_VIDEO_TYPES = [
  'video/mp4',
  'video/webm',
  'video/ogg',
  'video/quicktime',
  'video/x-msvideo',
]

const videoSchema = z.object({
  title: z
    .string()
    .min(3, { message: 'O título deve ter pelo menos 3 caracteres.' }),
  description: z
    .string()
    .min(10, { message: 'A descrição deve ter pelo menos 10 caracteres.' }),
  subject: z.string({ required_error: 'Você precisa selecionar uma matéria.' }),
  videoFile: z
    .instanceof(FileList)
    .refine((files) => files?.length === 1, 'É necessário enviar um arquivo.')
    .refine(
      (files) => files?.[0]?.size <= MAX_FILE_SIZE,
      `O tamanho máximo do arquivo é 500MB.`,
    )
    .refine(
      (files) => ACCEPTED_VIDEO_TYPES.includes(files?.[0]?.type),
      'Formatos de vídeo suportados: .mp4, .webm, .ogg, .mov, .avi',
    ),
})

type VideoFormValues = z.infer<typeof videoSchema>

export default function UploadVideo() {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)
  const { toast } = useToast()
  const { user } = useAuth()
  const navigate = useNavigate()

  const form = useForm<VideoFormValues>({
    resolver: zodResolver(videoSchema),
    defaultValues: {
      title: '',
      description: '',
      subject: undefined,
    },
  })

  const onSubmit = async (data: VideoFormValues) => {
    if (!user) return
    setIsSubmitting(true)
    setUploadProgress(0)

    const progressInterval = setInterval(() => {
      setUploadProgress((prev) => {
        if (prev >= 95) {
          clearInterval(progressInterval)
          return prev
        }
        return prev + 5
      })
    }, 200)

    try {
      await new Promise((resolve) => setTimeout(resolve, 2000))

      await createVideo({
        title: data.title,
        description: data.description,
        subject: data.subject,
        videoUrl:
          'https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
        uploaderId: user.id,
        likes: 0,
        views: 0,
        thumbnailUrl: `https://img.usecurling.com/p/400/225?q=${encodeURIComponent(
          data.subject,
        )}%20lesson`,
      })

      setUploadProgress(100)
      toast({
        title: 'Vídeo Enviado!',
        description: 'Seu vídeo foi enviado com sucesso para a plataforma.',
      })
      navigate('/videos')
    } catch (error) {
      toast({
        variant: 'destructive',
        title: 'Erro ao enviar vídeo',
      })
    } finally {
      clearInterval(progressInterval)
      setIsSubmitting(false)
    }
  }

  return (
    <div className="container mx-auto py-8 px-4 flex justify-center">
      <Card className="w-full max-w-2xl">
        <CardHeader>
          <CardTitle className="text-2xl">Postar Novo Vídeo</CardTitle>
          <CardDescription>
            Compartilhe seu conhecimento com a comunidade Subjescts.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="grid gap-6">
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Título do Vídeo</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="Ex: Equações de 2º Grau"
                        {...field}
                        disabled={isSubmitting}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Descrição</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Descreva o conteúdo do seu vídeo."
                        rows={4}
                        {...field}
                        disabled={isSubmitting}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="subject"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Disciplina</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                      disabled={isSubmitting}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Selecione a disciplina" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="Matemática">Matemática</SelectItem>
                        <SelectItem value="Português">Português</SelectItem>
                        <SelectItem value="História">História</SelectItem>
                        <SelectItem value="Ciências">Ciências</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="videoFile"
                render={({ field: { onChange, onBlur, name, ref } }) => (
                  <FormItem>
                    <FormLabel>Arquivo de Vídeo</FormLabel>
                    <FormControl>
                      <Input
                        type="file"
                        accept={ACCEPTED_VIDEO_TYPES.join(',')}
                        onChange={(e) => onChange(e.target.files)}
                        onBlur={onBlur}
                        name={name}
                        ref={ref}
                        disabled={isSubmitting}
                      />
                    </FormControl>
                    <FormDescription>
                      Selecione um arquivo de vídeo (máx 500MB).
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              {isSubmitting && (
                <div className="space-y-2">
                  <Progress value={uploadProgress} />
                  <p className="text-sm text-muted-foreground text-center">{`Enviando... ${uploadProgress}%`}</p>
                </div>
              )}
              <Button type="submit" className="w-full" disabled={isSubmitting}>
                <UploadCloud className="mr-2 h-4 w-4" />
                {isSubmitting ? 'Enviando...' : 'Enviar Vídeo'}
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  )
}
