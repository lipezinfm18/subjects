import { User, RegisterCredentials } from '@/types'

type StoredUser = User

let db: {
  users: StoredUser[]
} | null = null

const getDb = async (): Promise<{ users: StoredUser[] }> => {
  if (db) return db
  try {
    const response = await fetch('/db.json')
    if (!response.ok) throw new Error('Failed to fetch database.')
    const data = await response.json()
    db = data
    return db
  } catch (error) {
    console.error('Error initializing database:', error)
    db = { users: [] }
    return db
  }
}

const hashPassword = (password: string): string => `${password}_hashed`
const verifyPassword = (password: string, hash: string): boolean =>
  hashPassword(password) === hash

export const authService = {
  async login(
    email: string,
    password: string,
  ): Promise<Omit<StoredUser, 'password'>> {
    const data = await getDb()
    const user = data.users.find((u) => u.email === email)

    if (!user || !user.password || !verifyPassword(password, user.password)) {
      throw new Error('E-mail ou senha inválidos.')
    }

    const { password: _, ...userToReturn } = user
    return userToReturn
  },

  async register(
    credentials: RegisterCredentials,
  ): Promise<Omit<StoredUser, 'password'>> {
    const data = await getDb()
    if (data.users.some((u) => u.email === credentials.email)) {
      throw new Error('Este e-mail já está em uso.')
    }

    const newUser: StoredUser = {
      id: Math.max(0, ...data.users.map((u) => u.id)) + 1,
      name: credentials.name,
      email: credentials.email,
      password: hashPassword(credentials.password || ''),
      role: credentials.role,
      avatarUrl: `https://img.usecurling.com/ppl/large?seed=${Math.random()}`,
      score: 0,
      rank: data.users.length + 1,
      registeredAt: new Date().toISOString(),
    }

    data.users.push(newUser)

    const { password, ...userToReturn } = newUser
    return userToReturn
  },
}
