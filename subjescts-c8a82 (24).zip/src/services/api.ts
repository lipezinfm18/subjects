import {
  User,
  Video,
  Comment,
  Quiz,
  Task,
  CommunityPost,
  DashboardData,
} from '@/types'

let db: {
  users: User[]
  videos: Video[]
  comments: Comment[]
  quizzes: Quiz[]
  tasks: Task[]
  communityPosts: CommunityPost[]
} | null = null

const getDb = async () => {
  if (db) return db
  try {
    const response = await fetch('/db.json')
    if (!response.ok) throw new Error('Failed to fetch database.')
    const data = await response.json()
    db = data
    return db
  } catch (error) {
    console.error('Error initializing database:', error)
    db = {
      users: [],
      videos: [],
      comments: [],
      quizzes: [],
      tasks: [],
      communityPosts: [],
    }
    return db
  }
}

export const getUsers = async (): Promise<User[]> => {
  const data = await getDb()
  return data.users
}

export const updateUser = async (
  userId: number,
  userData: Partial<User>,
): Promise<User> => {
  const data = await getDb()
  const userIndex = data.users.findIndex((u) => u.id === userId)
  if (userIndex === -1) throw new Error('User not found')
  data.users[userIndex] = { ...data.users[userIndex], ...userData }
  return data.users[userIndex]
}

export const deleteUser = async (
  userId: number,
): Promise<{ success: true }> => {
  const data = await getDb()
  data.users = data.users.filter((u) => u.id !== userId)
  return { success: true }
}

export const getVideos = async (): Promise<Video[]> => {
  const data = await getDb()
  return data.videos
}

export const createVideo = async (
  videoData: Omit<Video, 'id'>,
): Promise<Video> => {
  const data = await getDb()
  const newVideo: Video = { ...videoData, id: Date.now().toString() }
  data.videos.unshift(newVideo)
  return newVideo
}

export const deleteVideo = async (
  videoId: string,
): Promise<{ success: true }> => {
  const data = await getDb()
  data.videos = data.videos.filter((v) => v.id !== videoId)
  return { success: true }
}

export const getTasks = async (userId: number): Promise<Task[]> => {
  const data = await getDb()
  return data.tasks.filter((t) => t.userId === userId)
}

export const createTask = async (taskData: Omit<Task, 'id'>): Promise<Task> => {
  const data = await getDb()
  const newTask: Task = { ...taskData, id: Date.now().toString() }
  data.tasks.unshift(newTask)
  return newTask
}

export const updateTask = async (
  taskId: string,
  taskData: Partial<Task>,
): Promise<Task> => {
  const data = await getDb()
  const taskIndex = data.tasks.findIndex((t) => t.id === taskId)
  if (taskIndex === -1) throw new Error('Task not found')
  data.tasks[taskIndex] = { ...data.tasks[taskIndex], ...taskData }
  return data.tasks[taskIndex]
}

export const deleteTask = async (
  taskId: string,
): Promise<{ success: true }> => {
  const data = await getDb()
  data.tasks = data.tasks.filter((t) => t.id !== taskId)
  return { success: true }
}

export const getQuizzes = async (): Promise<Quiz[]> => {
  const data = await getDb()
  return data.quizzes
}

export const createQuiz = async (quizData: Omit<Quiz, 'id'>): Promise<Quiz> => {
  const data = await getDb()
  const newQuiz: Quiz = { ...quizData, id: Date.now().toString() }
  data.quizzes.unshift(newQuiz)
  return newQuiz
}

export const deleteQuiz = async (
  quizId: string,
): Promise<{ success: true }> => {
  const data = await getDb()
  data.quizzes = data.quizzes.filter((q) => q.id !== quizId)
  return { success: true }
}

export const getComments = async (): Promise<Comment[]> => {
  const data = await getDb()
  return data.comments
}

export const updateCommentStatus = async (
  commentId: string,
  status: Comment['status'],
): Promise<Comment> => {
  const data = await getDb()
  const commentIndex = data.comments.findIndex((c) => c.id === commentId)
  if (commentIndex === -1) throw new Error('Comment not found')
  data.comments[commentIndex].status = status
  return data.comments[commentIndex]
}

export const deleteComment = async (
  commentId: string,
): Promise<{ success: true }> => {
  const data = await getDb()
  data.comments = data.comments.filter((c) => c.id !== commentId)
  return { success: true }
}

export const getDashboardData = async (): Promise<DashboardData> => {
  return {
    progress: 78,
    continueLearning: {
      subjectId: 'matematica',
      subjectName: 'Matemática',
      topicName: 'Álgebra - Funções do 1º Grau',
    },
    subjects: [
      { id: 'matematica', name: 'Matemática', icon: 'Book' },
      { id: 'portugues', name: 'Português', icon: 'Book' },
      { id: 'historia', name: 'História', icon: 'Book' },
    ],
    rankingEvolution: [
      { name: 'S-4', position: 60 },
      { name: 'S-3', position: 52 },
      { name: 'S-2', position: 35 },
      { name: 'S-1', position: 28 },
      { name: 'Hoje', position: 22 },
    ],
    communityNews: [
      {
        user: '@joao_vitor',
        text: 'Alguém tem dicas para a prova de física?',
      },
      {
        user: '@maria_clara',
        text: 'Amei o novo vídeo sobre a Grécia Antiga!',
      },
    ],
  }
}
