import { useState, useMemo } from 'react'
import { Video } from '@/types'

export interface AugmentedVideo extends Video {
  category:
    | 'Tutoriais'
    | 'Palestras'
    | 'Entrevistas'
    | 'Entretenimento'
    | 'Notícias'
}

export const useVideoFilters = (videos: AugmentedVideo[]) => {
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedCategories, setSelectedCategories] = useState<string[]>([])
  const [sortOrder, setSortOrder] = useState('recent')

  const filteredAndSortedVideos = useMemo(() => {
    let filtered = videos

    if (searchTerm) {
      filtered = filtered.filter(
        (video) =>
          video.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          video.description.toLowerCase().includes(searchTerm.toLowerCase()),
      )
    }

    if (selectedCategories.length > 0) {
      filtered = filtered.filter((video) =>
        selectedCategories.includes(video.category),
      )
    }

    const sorted = [...filtered].sort((a, b) => {
      switch (sortOrder) {
        case 'popular':
          return b.views - a.views
        case 'az':
          return a.title.localeCompare(b.title)
        case 'recent':
        default:
          return parseInt(b.id) - parseInt(a.id)
      }
    })

    return sorted
  }, [videos, searchTerm, selectedCategories, sortOrder])

  const clearFilters = () => {
    setSearchTerm('')
    setSelectedCategories([])
    setSortOrder('recent')
  }

  return {
    searchTerm,
    setSearchTerm,
    selectedCategories,
    setSelectedCategories,
    sortOrder,
    setSortOrder,
    clearFilters,
    filteredAndSortedVideos,
  }
}
