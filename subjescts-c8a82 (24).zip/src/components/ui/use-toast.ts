/* Use Toast Component - A component that displays a toast (a component that displays a notification) - from shadcn/ui (exposes useToast, toast) */
import { useToast, toast } from '@/hooks/use-toast'

export { useToast, toast }
