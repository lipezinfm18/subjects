import { LucideIcon } from 'lucide-react'

export type UserRole = 'student' | 'teacher' | 'admin'

export interface User {
  id: number
  name: string
  email: string
  password?: string
  role: UserRole
  avatarUrl: string
  series?: string
  institution?: string
  score: number
  rank: number
  registeredAt: string
}

export interface Video {
  id: string
  title: string
  description: string
  subject: string
  videoUrl: string
  thumbnailUrl: string
  uploaderId: number
  likes: number
  views: number
}

export interface Comment {
  id: string
  videoId: string
  userId: number
  text: string
  timestamp: string
  status: 'Pendente' | 'Aprovado' | 'Rejeitado'
}

export interface QuizQuestion {
  question: string
  options: string[]
  answer: string
}

export type Difficulty = 'Fácil' | 'Médio' | 'Difícil' | 'Impossível'

export interface Quiz {
  id: string
  title: string
  subject: string
  difficulty: Difficulty
  questions: QuizQuestion[]
}

export interface Task {
  id: string
  userId: number
  title: string
  dueDate: string | null
  status: 'pending' | 'completed'
}

export interface CommunityPost {
  id: string
  userId: number
  title: string
  content: string
  timestamp: string
  likes: number[]
  comments: CommunityComment[]
}

export interface CommunityComment {
  id: string
  userId: number
  text: string
  timestamp: string
}

export interface Subject {
  id: string
  name: string
  icon: string
}

export interface ContinueLearning {
  subjectId: string
  subjectName: string
  topicName: string
}

export interface RankingDataPoint {
  name: string
  position: number
}

export interface DashboardData {
  progress: number
  continueLearning: ContinueLearning
  subjects: Subject[]
  rankingEvolution: RankingDataPoint[]
  communityNews: { user: string; text: string }[]
}

export interface LoginCredentials {
  email: string
  password?: string
}

export interface RegisterCredentials extends LoginCredentials {
  name: string
  role: 'student' | 'teacher'
}
