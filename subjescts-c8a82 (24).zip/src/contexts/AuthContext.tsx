import {
  createContext,
  useState,
  useContext,
  ReactNode,
  useMemo,
  useCallback,
  useEffect,
} from 'react'
import { authService } from '@/services/authService'
import { updateUser as apiUpdateUser } from '@/services/api'
import { LoginCredentials, RegisterCredentials, User } from '@/types'

interface AuthContextType {
  isAuthenticated: boolean
  user: User | null
  login: (credentials: LoginCredentials) => Promise<User>
  register: (credentials: RegisterCredentials) => Promise<User>
  logout: () => void
  updateUser: (data: Partial<User>) => Promise<void>
  isLoading: boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const storedUser = sessionStorage.getItem('user')
    if (storedUser) {
      setUser(JSON.parse(storedUser))
    }
    setIsLoading(false)
  }, [])

  const login = useCallback(async (credentials: LoginCredentials) => {
    const loggedInUser = await authService.login(
      credentials.email,
      credentials.password || '',
    )
    setUser(loggedInUser)
    sessionStorage.setItem('user', JSON.stringify(loggedInUser))
    return loggedInUser
  }, [])

  const register = useCallback(async (credentials: RegisterCredentials) => {
    const registeredUser = await authService.register(credentials)
    return registeredUser
  }, [])

  const logout = useCallback(() => {
    setUser(null)
    sessionStorage.removeItem('user')
  }, [])

  const updateUser = useCallback(
    async (data: Partial<User>) => {
      if (!user) return
      try {
        const updatedUser = await apiUpdateUser(user.id, data)
        setUser(updatedUser)
        sessionStorage.setItem('user', JSON.stringify(updatedUser))
      } catch (error) {
        console.error('Failed to update user:', error)
      }
    },
    [user],
  )

  const value = useMemo(
    () => ({
      isAuthenticated: !!user,
      user,
      login,
      register,
      logout,
      updateUser,
      isLoading,
    }),
    [user, login, register, logout, updateUser, isLoading],
  )

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}
