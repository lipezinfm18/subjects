# Project built by Curling AI

This project was built by curling AI from ground up
