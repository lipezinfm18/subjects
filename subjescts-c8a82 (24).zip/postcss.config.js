/* PostCSS Config file: https://postcss.org */

export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}
